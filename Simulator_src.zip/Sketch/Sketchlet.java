package Sketch;


public interface Sketchlet {

}
