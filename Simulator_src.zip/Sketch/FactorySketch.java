package Sketch;

public interface FactorySketch {
    SuMaxSketch getSuMaxSketch();
    Sketchlet getSketchLet();
}
