package Common;

public class FlowInfo{
    public FlowID flowID;
    public double pps;
    public int packetNum;
    public int realSendNum;
    public boolean INT=false;

}
