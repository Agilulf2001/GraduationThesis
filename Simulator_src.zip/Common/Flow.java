package Common;

import java.util.Map;

public class Flow {
    Flow()
    {
        return;
    }
    private FlowID id;
    private Map<Integer, Packet> packets;
    private int GeneratePackets()   //generate packet
    {
        return 0;
    }

}
