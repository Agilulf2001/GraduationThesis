package Common;

public interface QueryData {
}
