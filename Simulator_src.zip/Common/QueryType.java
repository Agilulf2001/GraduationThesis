package Common;

public enum QueryType {
    QUERY_SIZE
}
