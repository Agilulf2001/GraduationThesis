package Common;

public class TelemetryData {
    public int packetSize;
}
